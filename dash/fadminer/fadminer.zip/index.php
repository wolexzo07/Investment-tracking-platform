<?php include_once("validate.php");?>
<?php include_once("head.php");?>
<?php include_once("logo.php");?>

	


		<div class="container-fluid" id="calculate">
								
		</div>


<?php include_once("footbase.php");?>
