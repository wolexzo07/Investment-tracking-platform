
<!--</fieldset>--->

</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"></div>
</div>  </div>      
	
  <script type="text/javascript">
            $(document).ready(function () {
				load('homedash'); // Initializing the homepage 
            });
        </script>
	
</body>
</html>