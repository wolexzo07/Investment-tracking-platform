

function open_stock(){

$(document).ready(function(){
	$(".stocks_add").toggle("slow");
	
	
	});
	
	} 














